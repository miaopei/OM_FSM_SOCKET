SPDX-License-Identifier: Apache-2.0
Copyright � 2020 Intel Corporation

- [Prerequisites](#prerequisites)
  - [System configuration](##systemconfiguration)
  - [SW configuration](#softwareconfiguraton)
- [Install package](#install)
- [Run sample application](#run)

# Prerequisites

## System configuration

### VFIO requires:
#### Linux:
- IOMMU=ON
- Example of Linux boot arguments
```
BOOT_IMAGE=/vmlinuz-3.10.0-957.10.1.rt56.921.el7.x86_64 root=/dev/mapper/centos-root ro crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap intel_iommu=on iommu=pt usbcore.autosuspend=-1 selinux=0 enforcing=0 nmi_watchdog=0 softlockup_panic=0 audit=0 intel_pstate=disable cgroup_memory=1 cgroup_enable=memory mce=off idle=poll hugepagesz=1G hugepages=16 hugepagesz=2M hugepages=0 default_hugepagesz=1G isolcpus=1-19,21-39 rcu_nocbs=1-19,21-39 kthread_cpus=0,20 irqaffinity=0,20 nohz_full=1-19,21-39
```

#### BIOS:
- Intel(R) Virtualization Technology Enabled
- Intel(R) VT for Directed I/O - Enabled
- ACS Control - Enabled
- Coherency Support - Disabled

## Software Configuration

### Intel Compiler

```bash
icc -v
icc version 19.0.3.206 (gcc version 4.8.5 compatibility)
```

### Networking Card

Install [i40e driver](https://sourceforge.net/projects/e1000/files/i40e%20stable/)and corespondind [firmware package](https://downloadcenter.intel.com/download/24769/Non-Volatile-Memory-NVM-Update-Utility-for-Intel-Ethernet-Network-Adapter-700-Series)

according to version below
```
ethtool -i enp33s0f0
driver: i40e
version: 2.10.19.82
firmware-version: 7.20 0x80007949 1.2585.0
...
```
### DPDK 19.11

Patch DPDK 19.11 with ORAN FH patch for FVL
```diff
diff --git a/drivers/net/i40e/i40e_ethdev.c b/drivers/net/i40e/i40e_ethdev.c
index 5999c96..70078fa 100644
--- a/drivers/net/i40e/i40e_ethdev.c
+++ b/drivers/net/i40e/i40e_ethdev.c
@@ -2312,7 +2312,7 @@ void i40e_flex_payload_reg_set_default(struct i40e_hw *hw)
        /* Map queues with MSIX interrupt */
        main_vsi->nb_used_qps = dev->data->nb_rx_queues -
                pf->nb_cfg_vmdq_vsi * RTE_LIBRTE_I40E_QUEUE_NUM_PER_VM;
-       i40e_vsi_queues_bind_intr(main_vsi, I40E_ITR_INDEX_DEFAULT);
+       i40e_vsi_queues_bind_intr(main_vsi, I40E_ITR_INDEX_NONE);
        i40e_vsi_enable_queues_intr(main_vsi);

        /* Map VMDQ VSI queues with MSIX interrupt */
@@ -2323,6 +2323,11 @@ void i40e_flex_payload_reg_set_default(struct i40e_hw *hw)
                i40e_vsi_enable_queues_intr(pf->vmdq[i].vsi);
        }

+       /* disable Rx descriptor read control */
+       i40e_aq_debug_write_global_register(hw,
+                                       0x0012A504,
+                                       0, NULL);
+
        /* enable FDIR MSIX interrupt */
        if (pf->fdir.fdir_vsi) {
                i40e_vsi_queues_bind_intr(pf->fdir.fdir_vsi,
diff --git a/drivers/net/i40e/i40e_ethdev_vf.c b/drivers/net/i40e/i40e_ethdev_vf.c
index 5dba092..63377bb 100644
--- a/drivers/net/i40e/i40e_ethdev_vf.c
+++ b/drivers/net/i40e/i40e_ethdev_vf.c
@@ -666,7 +666,7 @@ struct rte_i40evf_xstats_name_off {

        map_info = (struct virtchnl_irq_map_info *)cmd_buffer;
        map_info->num_vectors = 1;
-       map_info->vecmap[0].rxitr_idx = I40E_ITR_INDEX_DEFAULT;
+       map_info->vecmap[0].rxitr_idx = I40E_ITR_INDEX_NONE;
        map_info->vecmap[0].vsi_id = vf->vsi_res->vsi_id;
        /* Alway use default dynamic MSIX interrupt */
        map_info->vecmap[0].vector_id = vector_id;
```

Patch DPDK 19.11 with ORAN FH patch for CVL
```diff
diff --git a/drivers/net/ice/ice_ethdev.c b/drivers/net/ice/ice_ethdev.c
index c65125ff3..08f148613 100644
--- a/drivers/net/ice/ice_ethdev.c
+++ b/drivers/net/ice/ice_ethdev.c
@@ -3344,8 +3344,13 @@ __vsi_queues_bind_intr(struct ice_vsi *vsi, uint16_t msix_vect,

                PMD_DRV_LOG(INFO, "queue %d is binding to vect %d",
                            base_queue + i, msix_vect);
-               /* set ITR0 value */
-               ICE_WRITE_REG(hw, GLINT_ITR(0, msix_vect), 0x10);
+               /* set ITR0 value
+                * Empirical configuration for optimal real time latency
+                * reduced interrupt throttling to 2 ms
+                * Columbiaville pre-PRQ : local patch subject to change
+                */
+               ICE_WRITE_REG(hw, GLINT_ITR(0, msix_vect), 0x1);
+               ICE_WRITE_REG(hw, QRX_ITR(base_queue + i), QRX_ITR_NO_EXPR_M);
                ICE_WRITE_REG(hw, QINT_RQCTL(base_queue + i), val);
                ICE_WRITE_REG(hw, QINT_TQCTL(base_queue + i), val_tx);
        }
```


### compile DPDK in regular way

```
[root@5gnr-sc12-xran dpdk]# ./usertools/dpdk-setup.sh
select [39] x86_64-native-linuxapp-icc
select [46] Insert VFIO module
exit   [62] Exit Script
```

### Find PCIe device of Fortville port

```
lspci |grep Eth
19:00.0 Ethernet controller: Intel Corporation Ethernet Controller XXV710 Intel(R) FPGA Programmable Acceleration Card N3000 for Networking (rev 02)
19:00.1 Ethernet controller: Intel Corporation Ethernet Controller XXV710 Intel(R) FPGA Programmable Acceleration Card N3000 for Networking (rev 02)
1d:00.0 Ethernet controller: Intel Corporation Ethernet Controller XXV710 Intel(R) FPGA Programmable Acceleration Card N3000 for Networking (rev 02)
1d:00.1 Ethernet controller: Intel Corporation Ethernet Controller XXV710 Intel(R) FPGA Programmable Acceleration Card N3000 for Networking (rev 02)
21:00.0 Ethernet controller: Intel Corporation Ethernet Controller XXV710 for 25GbE SFP28 (rev 02) <<<
21:00.1 Ethernet controller: Intel Corporation Ethernet Controller XXV710 for 25GbE SFP28 (rev 02) <<<
67:00.0 Ethernet controller: Intel Corporation Ethernet Connection X722 for 10GBASE-T (rev 09)
67:00.1 Ethernet controller: Intel Corporation Ethernet Connection X722 for 10GBASE-T (rev 09)
```
### Configure corresponding Ethernet devices

```bash
#!/bin/bash

echo 2 > /sys/bus/pci/devices/0000\:21\:00.0/sriov_numvfs

ip link set enp33s0f0 vf 1 mac 00:11:22:33:44:66 vlan 1
ip link set enp33s0f0 vf 0 mac 00:11:22:33:44:66 vlan 2

echo 2 > /sys/bus/pci/devices/0000\:21\:00.1/sriov_numvfs
ip link set enp33s0f1 vf 1 mac 00:11:22:33:44:55 vlan 1
ip link set enp33s0f1 vf 0 mac 00:11:22:33:44:55 vlan 2

ip link  show
```

resulting output
```
 ip link show
...
6: enp33s0f0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 3c:fd:fe:b9:f8:b4 brd ff:ff:ff:ff:ff:ff
    vf 0 MAC 00:11:22:33:44:66, vlan 2, spoof checking on, link-state auto, trust off
    vf 1 MAC 00:11:22:33:44:66, vlan 1, spoof checking on, link-state auto, trust off
7: enp33s0f1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 3c:fd:fe:b9:f8:b5 brd ff:ff:ff:ff:ff:ff
    vf 0 MAC 00:11:22:33:44:55, vlan 2, spoof checking on, link-state auto, trust off
    vf 1 MAC 00:11:22:33:44:55, vlan 1, spoof checking on, link-state auto, trust off
8: eno1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether a4:bf:01:3e:1f:be brd ff:ff:ff:ff:ff:ff
...
```

For more information please see [DPDK documentation](https://doc.dpdk.org/guides/nics/intel_vf.html)

## Octave

version GNU Octave, version 3.8.2 is used to generate test IQ

`yum install octave-3.8.2-20.el7.x86_64`

## Google test

download [version 1.7.0](https://github.com/google/googletest/releases/tag/release-1.7.0)

Untar google test.
The recommended installation folder is /opt/gtest/
Example build and installation commands:
```
sudo tar -xvf googletest-release-1.7.0.tar.gz
sudo mv googletest-release-1.7.0 gtest-1.7.0
export GTEST_DIR=/opt/gtest/gtest-1.7.0
cd ${GTEST_DIR}
sudo g++ -isystem ${GTEST_DIR}/include -I${GTEST_DIR} -pthread -c ${GTEST_DIR}/src/gtest-all.cc
sudo ar -rv libgtest.a gtest-all.o
cd ${GTEST_DIR}/build-aux
sudo cmake ${GTEST_DIR}
sudo make
cd ${GTEST_DIR}
sudo ln -s build-aux/libgtest_main.a libgtest_main.a
```
add GTEST_ROOT to enviroument
```
export GTEST_ROOT=/opt/gtest/gtest-1.7.0
```

# Install

## Copy application to the system
```
.
+-- dpdk
|   ...
+-- dpdk-19.11-oran-fh.patch
+-- flexran_xran
    +-- app
    +-- banner.txt
    +-- build.sh
    +-- jenkins
    +-- lib
    +-- Licenses.txt
    +-- readme.txt
    +-- release
    +-- test
+-- gtest-1.7.0
|   ...
```

## Generate test IQ samples

```bash
cd flexran_xran/app
octave ./gen_test.m > octave_gen_test.log 2>&1
```

## Compile ORAN FH sample application

Example of enviroument variable

```bash
cat ./setenv.sh
export GTEST_ROOT=/opt/gtest/gtest-1.7.0
export RTE_SDK=`pwd`/dpdk
export RTE_TARGET=x86_64-native-linuxapp-icc
export XRAN_DIR=`pwd`/flexran_xran
```
Build project

```bash
source ./setenv.sh
./build.sh xclean
./build.sh
```
Example of output

```
 ./build.sh
Number of commandline arguments: 0
MLOG folder is set. Enable MLOG (MLOG_DIR=/home/turner/xran/master/npg_wireless-flexran_l1_sw/libs/mlog)
Building xRAN Library
LIBXRANSO    = 0
MLOG         = 1
GNU Make build
============================================================================================
Building ./build/libxran.a
     RTE_TARGET = x86_64-native-linuxapp-icc
============================================================================================
[BUILD] lib : libxran
[DEP] libxran.dep
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethdi.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethernet.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_up_api.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_sync_api.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_timer.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_api.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_transport.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_common.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_ul_tables.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_frame_struct.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_app_frag.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_dev.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_rx_proc.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_tx_proc.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_proc.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cb_proc.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mem_mgr.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_main.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_delay_measurement.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_ref.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_9b16rb.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mod_compression.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_snc.o
[AR] build/libxran.a
./build/libxran.a
Building xRAN Test Application
============================================================================================
Building ./build/sample-app
     RTE_TARGET = x86_64-native-linuxapp-icc
============================================================================================
[BUILD] elf : sample-app
[DEP] sample-app.dep
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/app/src/common.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/app/src/config.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/app/src/app_io_fh_xran.o
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/app/src/sample-app.o
[LD] build/sample-app
./build/sample-app
Building xRAN Test Application (/home/turner/xran/master/../master_aux/gtest-1.7.0)
Build Tests with
/home/turner/xran/master/npg_wireless-flexran_xran/lib/src
/home/turner/xran/master/npg_wireless-flexran_xran/lib/api
[DEP] unittests.dep
[CC] /home/turner/xran/master/npg_wireless-flexran_xran/test/common/xranlib_unit_test_main.o
[CC] c_plane_tests.o
[CC] chain_tests.o
[CC] prach_functional.o
[CC] prach_performance.o
[CC] u_plane_functional.o
[CC] u_plane_performance.o
[CC] init_sys_functional.o
[CC] compander_functional.o
[CC] mod_compression_unit_test.o
[CC] unittests.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/test/common/common.o
remark #11074: Inlining inhibited by limit max-size
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_ref.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_9b16rb.o
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mod_compression.o
remark #11074: Inlining inhibited by limit max-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8_snc.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16_snc.o
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32_snc.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64_snc.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[CPP-SNC] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_snc.o
remark #11074: Inlining inhibited by limit max-total-size
remark #11076: To get full report use -qopt-report=4 -qopt-report-phase ipo
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethdi.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethernet.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_up_api.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_sync_api.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_timer.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_api.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_transport.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_common.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_ul_tables.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_frame_struct.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_app_frag.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_dev.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_rx_proc.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_tx_proc.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_proc.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cb_proc.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mem_mgr.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_main.o
[C] /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_delay_measurement.o
[LD] unittests
icpc -isystem /home/turner/xran/master/../master_aux/gtest-1.7.0/include -I/home/turner/xran/master/npg_wireless-flexran_xran/lib/src -I/home/turner/xran/master/npg_wireless-flexran_xran/lib/api -g -std=c++14 -Wall -Wextra -pthread -mcmodel=large -I/home/turner/xran/master/npg_wireless-flexran_xran/lib/api -I/home/turner/xran/master/npg_wireless-flexran_xran/lib/src -I/home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet -I/home/turner/xran/master/npg_wireless-flexran_l1_sw/libs/mlog/source -I /home/turner/xran/master/npg_wireless-flexran_xran/test/common -I/home/turner/xran/master/isg_cid-wireless_dpdk_ae/x86_64-native-linuxapp-icc/include -L/home/turner/xran/master/npg_wireless-flexran_l1_sw/libs/mlog/bin -Wl, -L/home/turner/xran/master/isg_cid-wireless_dpdk_ae/x86_64-native-linuxapp-icc/lib -Wl,-lrte_flow_classify -Wl,--whole-archive -Wl,-lrte_pipeline -Wl,--no-whole-archive -Wl,--whole-archive -Wl,-lrte_table -Wl,--no-whole-archive -Wl,--whole-archive -Wl,-lrte_port -Wl,--no-whole-archive -Wl,-lrte_pdump -Wl,-lrte_distributor -Wl,-lrte_ip_frag -Wl,-lrte_meter -Wl,-lrte_lpm -Wl,--whole-archive -Wl,-lrte_acl -Wl,--no-whole-archive -Wl,-lrte_jobstats -Wl,-lrte_metrics -Wl,-lrte_bitratestats -Wl,-lrte_latencystats -Wl,-lrte_power -Wl,-lrte_efd -Wl,-lrte_bpf -Wl,--whole-archive -Wl,-lrte_cfgfile -Wl,-lrte_gro -Wl,-lrte_gso -Wl,-lrte_hash -Wl,-lrte_member -Wl,-lrte_vhost -Wl,-lrte_kvargs -Wl,-lrte_mbuf -Wl,-lrte_net -Wl,-lrte_ethdev -Wl,-lrte_bbdev -Wl,-lrte_cryptodev -Wl,-lrte_security -Wl,-lrte_compressdev -Wl,-lrte_eventdev -Wl,-lrte_rawdev -Wl,-lrte_timer -Wl,-lrte_mempool -Wl,-lrte_mempool_ring -Wl,-lrte_ring -Wl,-lrte_pci -Wl,-lrte_eal -Wl,-lrte_cmdline -Wl,-lrte_reorder -Wl,-lrte_sched -Wl,-lrte_kni -Wl,-lrte_common_octeontx -Wl,-lrte_bus_pci -Wl,-lrte_bus_vdev -Wl,-lrte_bus_dpaa -Wl,-lrte_common_dpaax -Wl,-lrte_stack -Wl,-lrte_bus_fslmc -Wl,-lrte_mempool_bucket -Wl,-lrte_mempool_stack -Wl,-lrte_mempool_dpaa -Wl,-lrte_mempool_dpaa2 -Wl,-lrte_pmd_af_packet -Wl,-lrte_pmd_ark -Wl,-lrte_pmd_iavf -Wl,-lrte_pmd_avp -Wl,-lrte_pmd_axgbe -Wl,-lrte_pmd_bnxt -Wl,-lrte_pmd_bond -Wl,-lrte_pmd_cxgbe -Wl,-lrte_pmd_dpaa -Wl,-lrte_pmd_dpaa2 -Wl,-lrte_pmd_e1000 -Wl,-lrte_pmd_ena -Wl,-lrte_pmd_enic -Wl,-lrte_pmd_fm10k -Wl,-lrte_pmd_failsafe -Wl,-lrte_pmd_i40e -Wl,-lrte_pmd_ixgbe -Wl,-lrte_pmd_kni -Wl,-lrte_pmd_lio -Wl,-lrte_pmd_nfp -Wl,-lrte_pmd_null -Wl,-lrte_pmd_qede -Wl,-lrte_pmd_ring -Wl,-lrte_pmd_softnic -Wl,-lrte_pmd_tap -Wl,-lrte_pmd_thunderx_nicvf -Wl,-lrte_pmd_vdev_netvsc -Wl,-lrte_pmd_virtio -Wl,-lrte_pmd_vhost -Wl,-lrte_pmd_ifc -Wl,-lrte_pmd_vmxnet3_uio -Wl,-lrte_bus_vmbus -Wl,-lrte_pmd_netvsc -Wl,-lrte_pmd_bbdev_null -Wl,-lrte_pmd_null_crypto -Wl,-lrte_pmd_crypto_scheduler -Wl,-lrte_pmd_dpaa2_sec -Wl,-lrte_pmd_dpaa_sec -Wl,-lrte_pmd_virtio_crypto -Wl,-lrte_pmd_octeontx_zip -Wl,-lrte_pmd_qat -Wl,-lrte_pmd_skeleton_event -Wl,-lrte_pmd_sw_event -Wl,-lrte_pmd_octeontx_ssovf -Wl,-lrte_pmd_dpaa_event -Wl,-lrte_pmd_dpaa2_event -Wl,-lrte_mempool_octeontx -Wl,-lrte_pmd_octeontx -Wl,-lrte_pmd_opdl_event -Wl,-lrte_rawdev_skeleton -Wl,-lrte_rawdev_dpaa2_cmdif -Wl,-lrte_rawdev_dpaa2_qdma -Wl,-lrte_bus_ifpga -Wl,--no-whole-archive -Wl,-lrt -Wl,-lm -Wl,-lnuma -Wl,-ldl -Wl, -lpthread -lnuma /home/turner/xran/master/npg_wireless-flexran_xran/test/common/xranlib_unit_test_main.o c_plane_tests.o chain_tests.o prach_functional.o prach_performance.o u_plane_functional.o u_plane_performance.o init_sys_functional.o compander_functional.o mod_compression_unit_test.o unittests.o /home/turner/xran/master/npg_wireless-flexran_xran/test/common/common.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_ref.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_9b16rb.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mod_compression.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_compression_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane8_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane16_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane32_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_cplane64_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_bfp_uplane_snc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethdi.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/ethernet/ethernet.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_up_api.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_sync_api.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_timer.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_api.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_transport.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_common.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_ul_tables.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_frame_struct.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_app_frag.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_dev.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_rx_proc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_tx_proc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cp_proc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_cb_proc.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_mem_mgr.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_main.o /home/turner/xran/master/npg_wireless-flexran_xran/lib/src/xran_delay_measurement.o /home/turner/xran/master/../master_aux/gtest-1.7.0/libgtest.a -o unittests
"make $COMMAND_LINE" command exited with code 0.
```

## update Ethernet ports used for ORAN FH

```bash
cat ./run_o_du.sh
#! /bin/bash

ulimit -c unlimited
echo 1 > /proc/sys/kernel/core_uses_pid

./build/sample-app -c ./usecase/cat_a/mu3_100mhz/config_file_o_du.dat -p 2 0000:21:02.0 0000:21:02.1
```

modify `dpdk.sh` according to setup Ethernet ports

```bash
cat ./dpdk.sh
...
$RTE_SDK/usertools/dpdk-devbind.py --status
if [ ${VM_DETECT} == 'HOST' ]; then
    #HOST
    $RTE_SDK/usertools/dpdk-devbind.py --bind=vfio-pci 0000:21:02.0 <<< port has to match VF function from step 1.11
    $RTE_SDK/usertools/dpdk-devbind.py --bind=vfio-pci 0000:21:02.1 <<< port has to match VF function from step 1.11
...
```

# Run
execution of sample application

### Run dpdk.sh to assign port to PMD

```bash
[root@5gnr-sc12-xran app]# ./dpdk.sh
...
Network devices using DPDK-compatible driver
============================================
0000:21:02.0 'XL710/X710 Virtual Function 154c' drv=vfio-pci unused=i40evf,igb_uio
0000:21:02.1 'XL710/X710 Virtual Function 154c' drv=vfio-pci unused=i40evf,igb_uio
...
```

### Run ORAN FH sample app

setup RU mac address in config_file_o_du.dat for corespondig usecase

e.g.
```bash
./build/sample-app --usecasefile ./usecase/cat_a/mu3_100mhz/usecase_du.cfg --num_eth_vfs 2 --vf_addr_o_xu_a "0000:21:02.0 0000:21:02.1"
```

make sure that MAC addresses are configured in the `usecase_du.cfg`

```bash
# remote O-XU 0 Eth Link 0
oXuRem0Mac0=00:11:22:33:00:01
oXuRem0Mac1=00:11:22:33:00:11

# remote O-XU 0 Eth Link 1
oXuRem0Mac2=00:11:22:33:00:21
oXuRem0Mac3=00:11:22:33:00:31
```

example of execution O-DU sample app
``` bash
[root@sc12-xran-sub6 master]# source ./setenv.sh
[root@sc12-xran-sub6 master]# cd app/
[root@sc12-xran-sub6 app]# ./run_o_du.sh


===========================================================================================================
SAMPLE-APP VERSION
===========================================================================================================
Version: #DIRTY#
build-date: Nov  9 2020
build-time: 11:05:27
System clock (rdtsc) resolution 1596250804 [Hz]
Ticks per us 1596
pmc[345226.327]: uds: sendto failed: No such file or directory
Machine is not synchronized using PTP!
app_parse_cmdline_args:275: ./usecase/cat_a/mu3_100mhz/usecase_du.cfg [len 42]
app_parse_cmdline_args:270: 2
app_parse_cmdline_args:287: port 0 0000:88:02.0,0000:88:02.1 [len 26]
app_parse_cmdline_args:292: port 0 0000:88:02.0 [len 13]
app_parse_cmdline_args:292: port 0 0000:88:02.1 [len 13]
p_args->usecase_file (./usecase/cat_a/mu3_100mhz/usecase_du.cfg)
appMode 0
instance_id 0
io_core 5 [core id]
io_worker 0x2000000 [mask]
oXuNum 1
EthLinkSpeed 25
EthLinkSpeed 1
oXuCfgFile0: ./config_file_o_du.dat
oXuRem00Mac00: 00:11:22:33:00:01
[xu 0 vf 0]RU MAC address: 00:11:22:33:00:01
oXuRem00Mac01: 00:11:22:33:00:11
[xu 0 vf 1]RU MAC address: 00:11:22:33:00:11
oXuRem00Mac02: 00:11:22:33:00:21
[xu 0 vf 2]RU MAC address: 00:11:22:33:00:21
oXuRem00Mac03: 00:11:22:33:00:31
[xu 0 vf 3]RU MAC address: 00:11:22:33:00:31
oXuRem01Mac00: 00:11:22:33:01:01
[xu 1 vf 0]RU MAC address: 00:11:22:33:01:01
oXuRem01Mac01: 00:11:22:33:01:11
[xu 1 vf 1]RU MAC address: 00:11:22:33:01:11
oXuRem01Mac02: 00:11:22:33:01:21
[xu 1 vf 2]RU MAC address: 00:11:22:33:01:21
oXuRem01Mac03: 00:11:22:33:01:31
[xu 1 vf 3]RU MAC address: 00:11:22:33:01:31
oXuRem02Mac00: 00:11:22:33:02:01
[xu 2 vf 0]RU MAC address: 00:11:22:33:02:01
oXuRem02Mac01: 00:11:22:33:02:11
[xu 2 vf 1]RU MAC address: 00:11:22:33:02:11
oXuRem02Mac02: 00:11:22:33:02:21
[xu 2 vf 2]RU MAC address: 00:11:22:33:02:21
oXuRem02Mac03: 00:11:22:33:02:31
[xu 2 vf 3]RU MAC address: 00:11:22:33:02:31
68 lines of config file has been read.
dir (./usecase/cat_a/mu3_100mhz)
cfg_file (./usecase/cat_a/mu3_100mhz/./config_file_o_du.dat)

=================== O-XU 0===================
instance_id 0
mu_number: 3
nDLAbsFrePointA: 27968160
nULAbsFrePointA: 27968160
nDLBandwidth: 100
nULBandwidth: 100
nDLFftSize: 1024
nULFftSize: 1024
nFrameDuplexType: 1
nTddPeriod: 4
sSlotConfig0: 0 0 0 0 0 0 0 0 0 0 0 0 0 0
sSlotConfig1: 0 0 0 0 0 0 0 0 0 0 0 0 0 0
sSlotConfig2: 0 0 0 0 0 0 0 0 0 0 0 0 0 0
sSlotConfig3: 0 2 2 1 1 1 1 1 1 1 1 1 1 1
mtu 9600
GPS_Alpha: 0
GPS_Beta: 0
io_core 5 [core id]
duMac0: 00:11:22:33:44:66
[vf 0]O-DU MAC address: 00:11:22:33:44:66
ruMac0: 00:11:22:33:44:55
[vf 0]RU MAC address: 00:11:22:33:44:55
duMac1: 00:11:22:33:44:66
[vf 1]O-DU MAC address: 00:11:22:33:44:66
ruMac1: 00:11:22:33:44:55
[vf 1]RU MAC address: 00:11:22:33:44:55
duMac2: 00:11:22:33:44:77
[vf 2]O-DU MAC address: 00:11:22:33:44:77
ruMac2: 00:11:22:33:44:44
[vf 2]RU MAC address: 00:11:22:33:44:44
duMac3: 00:11:22:33:44:77
[vf 3]O-DU MAC address: 00:11:22:33:44:77
ruMac3: 00:11:22:33:44:44
[vf 3]RU MAC address: 00:11:22:33:44:44
maxFrameId: 99
numSlots: 20
antC0: ./usecase/cat_a/mu3_100mhz/ant_0.bin
antC1: ./usecase/cat_a/mu3_100mhz/ant_1.bin
antC2: ./usecase/cat_a/mu3_100mhz/ant_2.bin
antC3: ./usecase/cat_a/mu3_100mhz/ant_3.bin
antC4: ./usecase/cat_a/mu3_100mhz/ant_4.bin
antC5: ./usecase/cat_a/mu3_100mhz/ant_5.bin
antC6: ./usecase/cat_a/mu3_100mhz/ant_6.bin
antC7: ./usecase/cat_a/mu3_100mhz/ant_7.bin
antC8: ./usecase/cat_a/mu3_100mhz/ant_8.bin
antC9: ./usecase/cat_a/mu3_100mhz/ant_9.bin
antC10: ./usecase/cat_a/mu3_100mhz/ant_10.bin
antC11: ./usecase/cat_a/mu3_100mhz/ant_11.bin
antC12: ./usecase/cat_a/mu3_100mhz/ant_12.bin
antC13: ./usecase/cat_a/mu3_100mhz/ant_13.bin
antC14: ./usecase/cat_a/mu3_100mhz/ant_14.bin
antC15: ./usecase/cat_a/mu3_100mhz/ant_15.bin
Prach enable: 1
Prach config index: 81
debugStop: 1
debugStopCount: 0
bbdevMode: 0
CPenable: 1
cp_vlan_tag: 1
up_vlan_tag: 2
totalBFWeights : 32
Tadv_cp_dl: 25
T2a_min_cp_dl: 50
T2a_max_cp_dl: 140
T2a_min_cp_ul: 50
T2a_max_cp_ul: 140
T2a_min_up: 25
T2a_max_up: 70
Ta3_min: 20
Ta3_max: 32
T1a_min_cp_dl: 70
T1a_max_cp_dl: 100
T1a_min_cp_ul: 60
T1a_max_cp_ul: 70
T1a_min_up: 35
T1a_max_up: 50
Ta4_min: 0
Ta4_max: 45
147 lines of config file has been read.
This system has 80 processors configured and 80 processors available.
app_set_main_core [CPU  0] [PID: 303653]
set O-DU
bit_cuPortId     12 mask 0xf000
bit_bandSectorId  8 mask 0x0f00
bit_ccId          4 mask 0x00f0
ruPortId          0 mask 0x000f
VF[0] 0000:88:02.0
VF[1] 0000:88:02.1
p_use_cfg->num_vfs 2
'DPDK 19.11.0'
 xran_init: MTU 9600
PF Eth line speed 25G
PF Eth lines per O-xU port 1
total cores 80 c_mask 0x00000000002000021 core 5 [id] system_core 0 [id] pkt_proc_core 0x00000000002000000 [mask] pkt_aux_core 0 [id] timing_core 5 [id]
xran_ethdi_init_dpdk_io: Calling rte_eal_init:wls_0 -c 0x00000000002000021 -n2 --iova-mode=pa --socket-mem=8192 --socket-limit=8192 --proc-type=auto --file-prefix wls_0 -w0000:00:00.0
EAL: Detected 80 lcore(s)
EAL: Detected 2 NUMA nodes
EAL: Auto-detected process type: PRIMARY
EAL: Multi-process socket /var/run/dpdk/wls_0/mp_socket
EAL: Selected IOVA mode 'PA'
EAL: No available hugepages reported in hugepages-2048kB
EAL: Probing VFIO support...
EAL: VFIO support initialized
xran_init_mbuf_pool: socket 0
EAL: PCI device 0000:88:02.0 on NUMA socket 1
EAL:   probe driver: 8086:154c net_i40e_vf
EAL:   using IOMMU type 1 (Type 1)
initializing port 0 for TX, drv=net_i40e_vf
Port 0 MAC: 00 11 22 33 00 00
Port 0: nb_rxd 4096 nb_txd 4096
[0] mempool_rx__0
[0] mempool_small__0

Checking link status portid [0]   ... done
Port 0 Link Up - speed 25000 Mbps - full-duplex
EAL: PCI device 0000:88:02.1 on NUMA socket 1
EAL:   probe driver: 8086:154c net_i40e_vf
initializing port 1 for TX, drv=net_i40e_vf
Port 1 MAC: 00 11 22 33 01 00
Port 1: nb_rxd 4096 nb_txd 4096
[1] mempool_rx__1
[1] mempool_small__1

Checking link status portid [1]   ... done
Port 1 Link Up - speed 25000 Mbps - full-duplex
[ 0] vf  0 local  SRC MAC: 00 11 22 33 00 00
[ 0] vf  0 remote DST MAC: 00 11 22 33 00 01
[ 0] vf  1 local  SRC MAC: 00 11 22 33 01 00
[ 0] vf  1 remote DST MAC: 00 11 22 33 00 11
created dl_gen_ring_up_0
nSW_ToFpga_FTH_TxBufferLen 4276
Numm CC 1 numAxc 4 numUlAxc 4
IQ files size is 20 slots
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
Loading file ./usecase/cat_a/mu3_100mhz/ant_0.bin to  DL IFFT IN IQ Samples in binary format: Reading IQ samples from file: File Size: 887040 [Buffer Size: 887040]
from addr (0x7f809cd21010) size (887040) bytes num (887040)
Loading file ./usecase/cat_a/mu3_100mhz/ant_1.bin to  DL IFFT IN IQ Samples in binary format: Reading IQ samples from file: File Size: 887040 [Buffer Size: 887040]
from addr (0x7f809cc48010) size (887040) bytes num (887040)
Loading file ./usecase/cat_a/mu3_100mhz/ant_2.bin to  DL IFFT IN IQ Samples in binary format: Reading IQ samples from file: File Size: 887040 [Buffer Size: 887040]
from addr (0x7f805da7f010) size (887040) bytes num (887040)
Loading file ./usecase/cat_a/mu3_100mhz/ant_3.bin to  DL IFFT IN IQ Samples in binary format: Reading IQ samples from file: File Size: 887040 [Buffer Size: 887040]
from addr (0x7f805d9a6010) size (887040) bytes num (887040)
Storing DL IFFT IN IQ Samples in human readable format to file ./logs/o-du0-play_ant0.txt: from addr (0x7f809cd21010) size (887040) IQ num (221760)
Storing DL IFFT IN IQ Samples in binary format to file ./logs/o-du0-play_ant0.bin: from addr (0x7f809cd21010) size (443520) bytes num (443520)
Storing DL IFFT IN IQ Samples in human readable format to file ./logs/o-du0-play_ant1.txt: from addr (0x7f809cc48010) size (887040) IQ num (221760)
Storing DL IFFT IN IQ Samples in binary format to file ./logs/o-du0-play_ant1.bin: from addr (0x7f809cc48010) size (443520) bytes num (443520)
Storing DL IFFT IN IQ Samples in human readable format to file ./logs/o-du0-play_ant2.txt: from addr (0x7f805da7f010) size (887040) IQ num (221760)
Storing DL IFFT IN IQ Samples in binary format to file ./logs/o-du0-play_ant2.bin: from addr (0x7f805da7f010) size (443520) bytes num (443520)
Storing DL IFFT IN IQ Samples in human readable format to file ./logs/o-du0-play_ant3.txt: from addr (0x7f805d9a6010) size (887040) IQ num (221760)
Storing DL IFFT IN IQ Samples in binary format to file ./logs/o-du0-play_ant3.bin: from addr (0x7f805d9a6010) size (443520) bytes num (443520)
TX: Convert S16 I and S16 Q to network byte order for XRAN Ant: [0]
TX: Convert S16 I and S16 Q to network byte order for XRAN Ant: [1]
TX: Convert S16 I and S16 Q to network byte order for XRAN Ant: [2]
TX: Convert S16 I and S16 Q to network byte order for XRAN Ant: [3]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
app_xran_get_num_rbs: RAN [5G NR] nNumerology[3] nBandwidth[100] nAbsFrePointA[27968160] numRBs[66]
FFT Order 10
app_xran_cal_nrarfcn: nCenterFreq[28015680] nDeltaFglobal[60] nFoffs[24250080] nNoffs[2016667] nNRARFCN[2079427]
DL center freq 28015680 DL NR-ARFCN  2079427
app_xran_cal_nrarfcn: nCenterFreq[28015680] nDeltaFglobal[60] nFoffs[24250080] nNoffs[2016667] nNRARFCN[2079427]
UL center freq 28015680 UL NR-ARFCN  2079427
Max Sections: 6 per symb 6 per slot
 xran_open: 5G NR Category A
xRAN open PRACH config: Numerology 3 ConfIdx 81, preambleFmrt 6 startsymb 7, numSymbol 6, occassionsInPrachSlot 1
PRACH: x 1 y[0] 0, y[1] 0 prach slot: 3 .. 5 .. 7 .. 9 .. 11 .. 13 ..
PRACH start symbol 7 lastsymbol 12
xran_init_vfs_mapping: p 0 vf 0
xran_init_vfs_mapping: p 0 vf 1
xran_max_frame 99
xran_open: interval_us=125
XRAN_UP_VF: 0x0000
xran_timing_source_thread [CPU  5] [PID: 303653]
TTI interval 125 [us]
Start C-plane DL 25 us after TTI  [trigger on sym 3]
Start C-plane UL 55 us after TTI  [trigger on sym 7]
Start U-plane DL 50 us before OTA [offset  in sym -5]
Start U-plane UL 45 us OTA        [offset  in sym 6]
C-plane to U-plane delay 25 us after TTI
Start Sym timer 8928 ns
O-XU      0
HW        0
Num cores 2
Num ports 1
O-RU Cat  0
O-RU CC   1
O-RU eAxC 4
p:0 XRAN_JOB_TYPE_CP_DL worker id 1
p:0 XRAN_JOB_TYPE_CP_UL worker id 1
spawn worker 0 core 25
xran_open [CPU  0] [PID: 303653]
Waithing on Timing thread...
xran_generic_worker_thread [CPU 25] [PID: 303653]
XRAN front haul xran_mm_init
xran_sector_get_instances [0]: CC 0 handle 0x6f07c800
Handle: 0x7f806c9bd100 Instance: 0x6f07c800
app_io_xran_interface [0]: CC 0 handle 0x6f07c800
Sucess xran_mm_init
nSectorNum 1
xran_max_sections_per_slot 6
nSectorIndex[0] = 0
ru_0_cc_0_idx_0: [ handle 0x6f07c800 0 0 ] [nPoolIndex 0] nNumberOfBuffers 1120 nBufferSize 4276
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 0] mb pool 0x27e70c780
ru_0_cc_0_idx_1: [ handle 0x6f07c800 0 0 ] [nPoolIndex 1] nNumberOfBuffers 6720 nBufferSize 32
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 1] mb pool 0x27e0648c0
size_of_prb_map 7408
ru_0_cc_0_idx_2: [ handle 0x6f07c800 0 0 ] [nPoolIndex 2] nNumberOfBuffers 1120 nBufferSize 7408
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 2] mb pool 0x27db21280
ru_0_cc_0_idx_3: [ handle 0x6f07c800 0 0 ] [nPoolIndex 3] nNumberOfBuffers 1120 nBufferSize 4276
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 3] mb pool 0x27d10d740
ru_0_cc_0_idx_4: [ handle 0x6f07c800 0 0 ] [nPoolIndex 4] nNumberOfBuffers 6720 nBufferSize 32
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 4] mb pool 0x27ca65880
ru_0_cc_0_idx_5: [ handle 0x6f07c800 0 0 ] [nPoolIndex 5] nNumberOfBuffers 1120 nBufferSize 7408
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 5] mb pool 0x27c522240
ru_0_cc_0_idx_6: [ handle 0x6f07c800 0 0 ] [nPoolIndex 6] nNumberOfBuffers 1120 nBufferSize 3360
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 6] mb pool 0x27bb0e700
app_io_xran_interface:592: xran_max_ant_array_elm_nr 4
ru_0_cc_0_idx_7: [ handle 0x6f07c800 0 0 ] [nPoolIndex 7] nNumberOfBuffers 1120 nBufferSize 4276
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 7] mb pool 0x27b55bbc0
ru_0_cc_0_idx_8: [ handle 0x6f07c800 0 0 ] [nPoolIndex 8] nNumberOfBuffers 6720 nBufferSize 32
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 8] mb pool 0x27aeb3d00
ru_0_cc_0_idx_9: [ handle 0x6f07c800 0 0 ] [nPoolIndex 9] nNumberOfBuffers 1120 nBufferSize 7408
CC:[ handle 0x6f07c800 ru 0 cc_idx 0 ] [nPoolIndex 9] mb pool 0x27a9706c0
app_io_xran_iq_content_init
MLogOpen: filename(mlog-o-du.bin) mlogSubframes (128), mlogCores(7), mlogSize(20000) mlog_mask (0)
    mlogSubframes (128), mlogCores(7), mlogSize(20000)
    localMLogTimerInit
        System clock (rdtsc)  resolution 1596243109 [Hz]
        Ticks per us 1596
    MLog Storage: 0x7f805c18e100 -> 0x7f805d2a9f40 [ 17940032 bytes ]
    localMLogFreqReg: 1596. Storing: 1596
    Mlog Open successful

----------------------------------------
MLog Info: virt=0x00007f805c18e100 size=17940032
----------------------------------------
Start XRAN traffic
O-DU: XRAN start time: 11/16/20 21:04:40.889117475 UTC [125]
+---------------------------------------+
| Press 1 to start 5G NR XRAN traffic   |
| Press 2 reserved for future use       |
| Press 3 to quit                       |
+---------------------------------------+
O-DU: thread_run start time: 11/16/20 21:04:41.000000008 UTC [125]
[o-du0][rx       0 pps       0 kbps       0][tx       0 pps       0 kbps       0] [on_time 0 early 0 late 0 corrupt 0 pkt_dupl 0 Total 0]
[o-du0][rx       0 pps       0 kbps       0][tx  343631 pps  343631 kbps       2] [on_time 0 early 0 late 0 corrupt 0 pkt_dupl 0 Total 0]
...
[o-du0][rx       0 pps       0 kbps       0][tx 10776373 pps  386407 kbps 8813675] [on_time 0 early 0 late 0 corrupt 0 pkt_dupl 0 Total 0]
3
[o-du0][rx       0 pps       0 kbps       0][tx 11162758 pps  386385 kbps 8813726] [on_time 0 early 0 late 0 corrupt 0 pkt_dupl 0 Total 0]
Stop XRAN traffic
fh_rx_bbdev-25 worker thread finished on core 25 [worker id 0]
Closing timing source thread...
app_io_xran_iq_content_get
Closing l1 app... Ending all threads...
MLogPrint: ext_filename((null).bin)
    Opening MLog File: mlog-o-du-c0.bin
    MLog file mlog-o-du-c0.bin closed
    Mlog Print successful

Failed at  xran_mm_destroy, status -2
Dump IQs...
RX: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [0]
RX: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [1]
RX: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [2]
RX: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [3]
Storing UL FFT OUT IQ Samples in human readable format to file ./logs/o-du0-rx_log_ant0.txt: from addr (0x7f805d8cd010) size (887040) IQ num (221760)
Storing UL FFT OUT IQ Samples in binary format to file ./logs/o-du0-rx_log_ant0.bin: from addr (0x7f805d8cd010) size (443520) bytes num (443520)
Storing UL FFT OUT IQ Samples in human readable format to file ./logs/o-du0-rx_log_ant1.txt: from addr (0x7f805d7f4010) size (887040) IQ num (221760)
Storing UL FFT OUT IQ Samples in binary format to file ./logs/o-du0-rx_log_ant1.bin: from addr (0x7f805d7f4010) size (443520) bytes num (443520)
Storing UL FFT OUT IQ Samples in human readable format to file ./logs/o-du0-rx_log_ant2.txt: from addr (0x7f805d71b010) size (887040) IQ num (221760)
Storing UL FFT OUT IQ Samples in binary format to file ./logs/o-du0-rx_log_ant2.bin: from addr (0x7f805d71b010) size (443520) bytes num (443520)
Storing UL FFT OUT IQ Samples in human readable format to file ./logs/o-du0-rx_log_ant3.txt: from addr (0x7f805d642010) size (887040) IQ num (221760)
Storing UL FFT OUT IQ Samples in binary format to file ./logs/o-du0-rx_log_ant3.bin: from addr (0x7f805d642010) size (443520) bytes num (443520)
PRACH: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [0]
PRACH: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [1]
PRACH: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [2]
PRACH: Convert S16 I and S16 Q to cpu byte order from XRAN Ant: [3]
Storing PRACH IQ Samples in human readable format to file ./logs/o-du0-prach_log_ant0.txt: from addr (0x7f805d55c010) size (940800) IQ num (235200)
Storing PRACH IQ Samples in binary format to file ./logs/o-du0-prach_log_ant0.bin: from addr (0x7f805d55c010) size (470400) bytes num (470400)
Storing PRACH IQ Samples in human readable format to file ./logs/o-du0-prach_log_ant1.txt: from addr (0x7f805d476010) size (940800) IQ num (235200)
Storing PRACH IQ Samples in binary format to file ./logs/o-du0-prach_log_ant1.bin: from addr (0x7f805d476010) size (470400) bytes num (470400)
Storing PRACH IQ Samples in human readable format to file ./logs/o-du0-prach_log_ant2.txt: from addr (0x7f805d390010) size (940800) IQ num (235200)
Storing PRACH IQ Samples in binary format to file ./logs/o-du0-prach_log_ant2.bin: from addr (0x7f805d390010) size (470400) bytes num (470400)
Storing PRACH IQ Samples in human readable format to file ./logs/o-du0-prach_log_ant3.txt: from addr (0x7f805d2aa010) size (940800) IQ num (235200)
Storing PRACH IQ Samples in binary format to file ./logs/o-du0-prach_log_ant3.bin: from addr (0x7f805d2aa010) size (470400) bytes num (470400)
```

### Run Unittests

```bash
[root@sc12-xran-sub6 master]# source ./setenv.sh
[root@sc12-xran-sub6 master]# cd ./flexran_xran/test/test_xran/
[root@sc12-xran-sub6 test_xran]# ./unittests
O-DU MAC address: 00:11:22:33:44:66
O-RU MAC address: 00:11:22:33:44:66
eAxCID - 12:8:4:0 (f000, 0f00, 00f0, 000f)
Total BF Weights : 64
...

[       OK ] UnitTest/BfpPerfCp.AVX512_CpDeComp/14 (0 ms)
[ RUN      ] UnitTest/BfpPerfCp.AVX512_CpDeComp/15
[----------] Test case: AntElm_64_IQ_12
[----------] Mean = 0.021467 us
[----------] Stddev = 0.000073 us
[       OK ] UnitTest/BfpPerfCp.AVX512_CpDeComp/15 (0 ms)
[----------] 32 tests from UnitTest/BfpPerfCp (4 ms total)

[----------] Global test environment tear-down
[==========] 320 tests from 9 test cases ran. (6762 ms total)
[  PASSED  ] 320 tests.
```