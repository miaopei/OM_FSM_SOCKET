#!/bin/bash
#/******************************************************************************
#*
#*   Copyright (c) 2020 Intel.
#*
#*   Licensed under the Apache License, Version 2.0 (the "License");
#*   you may not use this file except in compliance with the License.
#*   You may obtain a copy of the License at
#*
#*       http://www.apache.org/licenses/LICENSE-2.0
#*
#*   Unless required by applicable law or agreed to in writing, software
#*   distributed under the License is distributed on an "AS IS" BASIS,
#*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#*   See the License for the specific language governing permissions and
#*   limitations under the License.
#*
#*******************************************************************************/

dmesg -c

echo 0 > /sys/bus/pci/devices/0000\:51\:00.0/sriov_numvfs
echo 0 > /sys/bus/pci/devices/0000\:51\:00.1/sriov_numvfs
echo 0 > /sys/bus/pci/devices/0000\:51\:00.2/sriov_numvfs
echo 0 > /sys/bus/pci/devices/0000\:51\:00.3/sriov_numvfs
echo 0 > /sys/bus/pci/devices/0000\:18\:00.0/sriov_numvfs
echo 0 > /sys/bus/pci/devices/0000\:18\:00.1/sriov_numvfs

modprobe -r ice
modprobe ice

modprobe -r iavf
modprobe iavf

echo 1 > /sys/bus/pci/devices/0000\:51\:00.0/sriov_numvfs
echo 1 > /sys/bus/pci/devices/0000\:51\:00.1/sriov_numvfs
echo 1 > /sys/bus/pci/devices/0000\:51\:00.2/sriov_numvfs
echo 1 > /sys/bus/pci/devices/0000\:51\:00.3/sriov_numvfs
echo 1 > /sys/bus/pci/devices/0000\:18\:00.0/sriov_numvfs
echo 1 > /sys/bus/pci/devices/0000\:18\:00.1/sriov_numvfs


ip link set enp81s0f0 vf 0 mac 00:11:22:33:00:00 vlan 1
ip link set enp81s0f1 vf 0 mac 00:11:22:33:00:10 vlan 1

ip link set enp81s0f2 vf 0 mac 00:11:22:33:01:00 vlan 2
ip link set enp81s0f3 vf 0 mac 00:11:22:33:01:10 vlan 2

ip link set enp24s0f0 vf 0 mac 00:11:22:33:02:00 vlan 3
ip link set enp24s0f1 vf 0 mac 00:11:22:33:02:10 vlan 3


dmesg -c

ip link  show


