/******************************************************************************
*
*   Copyright (c) 2020 Intel.
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
*
*******************************************************************************/

/**
 * @brief XRAN TX functionality
 * @file xran_tx.c
 * @ingroup group_source_xran
 * @author Intel Corporation
 **/

#define _GNU_SOURCE
#include <sched.h>
#include <assert.h>
#include <err.h>
#include <libgen.h>
#include <sys/time.h>
#include <sys/queue.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <malloc.h>
#include <immintrin.h>

#include <rte_common.h>
#include <rte_eal.h>
#include <rte_errno.h>
#include <rte_lcore.h>
#include <rte_cycles.h>
#include <rte_memory.h>
#include <rte_memzone.h>
#include <rte_mbuf.h>
#include <rte_ring.h>

#include "xran_fh_o_du.h"

#include "ethdi.h"
#include "xran_pkt.h"
#include "xran_up_api.h"
#include "xran_cp_api.h"
#include "xran_sync_api.h"
#include "xran_lib_mlog_tasks_id.h"
#include "xran_timer.h"
#include "xran_main.h"
#include "xran_common.h"
#include "xran_dev.h"
#include "xran_frame_struct.h"
#include "xran_printf.h"
#include "xran_app_frag.h"
#include "xran_tx_proc.h"
#include "xran_cp_proc.h"

#include "xran_mlog_lnx.h"

enum xran_in_period
{
     XRAN_IN_PREV_PERIOD  = 0,
     XRAN_IN_CURR_PERIOD,
     XRAN_IN_NEXT_PERIOD
};


extern int32_t xran_is_prach_slot(uint32_t subframe_id, uint32_t slot_id);

struct rte_mbuf *
xran_attach_up_ext_buf(uint16_t vf_id, int8_t* p_ext_buff_start, int8_t* p_ext_buff, uint16_t ext_buff_len,
                struct rte_mbuf_ext_shared_info * p_share_data,
                enum xran_compression_method compMeth);


static void
extbuf_free_callback(void *addr __rte_unused, void *opaque __rte_unused)
{
    /*long t1 = MLogTick();
    MLogTask(77777, t1, t1+100);*/
}

static inline int32_t XranOffsetSym(int32_t offSym, int32_t otaSym, int32_t numSymTotal, enum xran_in_period* pInPeriod)
{
    int32_t sym;

    // Suppose the offset is usually small
    if (unlikely(offSym > otaSym))
    {
        sym = numSymTotal - offSym + otaSym;
        *pInPeriod = XRAN_IN_PREV_PERIOD;
    }
    else
    {
        sym = otaSym - offSym;

        if (unlikely(sym >= numSymTotal))
        {
            sym -= numSymTotal;
            *pInPeriod = XRAN_IN_NEXT_PERIOD;
        }
        else
        {
            *pInPeriod = XRAN_IN_CURR_PERIOD;
        }
    }

    return sym;
}

// Return SFN at current second start, 10 bits, [0, 1023]
uint16_t xran_getSfnSecStart(void)
{
    return xran_SFN_at_Sec_Start;
}

/* Send burst of packets on an output interface */
static inline int
xran_send_burst(struct xran_device_ctx *dev, struct mbuf_table* p_m_table, uint16_t port)
{
    struct xran_common_counters *  pCnt  = NULL;
    struct rte_mbuf **m_table;
    int32_t i   = 0;
    int32_t n   = 0;
    int32_t ret = 0;

    if(dev)
        pCnt = &dev->fh_counters;
    else
        rte_panic("incorrect dev\n");

    m_table = p_m_table->m_table;
    n       = p_m_table->len;

    for(i = 0; i < n; i++) {
        /*rte_mbuf_sanity_check(m_table[i], 0);*/
        /*rte_pktmbuf_dump(stdout, m_table[i], 256);*/
        pCnt->tx_counter++;
        pCnt->tx_bytes_counter += rte_pktmbuf_pkt_len(m_table[i]);
        ret += dev->send_upmbuf2ring(m_table[i], ETHER_TYPE_ECPRI, port);
    }

    if (unlikely(ret < n)) {
        print_err("core %d [p: %d-> vf %d] ret [%d] < n[%d] enq %ld\n",
             rte_lcore_id(), dev->xran_port_id, port, ret, n, pCnt->tx_counter);
    }

    return 0;
}

int32_t xran_process_tx_sym_cp_off(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id, uint32_t slot_id, uint32_t sym_id,
    int32_t do_srs)
{
    int32_t     retval = 0;
    char        *pos = NULL;
    char        *p_sec_iq = NULL;
    void        *mb  = NULL;
    void        *send_mb  = NULL;
    int         prb_num = 0;
    uint16_t    iq_sample_size_bits = 16;
    uint16_t    vf_id = 0;

    struct xran_prb_map *prb_map = NULL;
    uint8_t  num_ant_elm  = 0;

    struct xran_device_ctx * p_xran_dev_ctx = (struct xran_device_ctx *)pHandle;
    struct xran_common_counters * pCnt = &p_xran_dev_ctx->fh_counters;
    struct xran_prach_cp_config *pPrachCPConfig = &(p_xran_dev_ctx->PrachCPConfig);
    struct xran_srs_config *p_srs_cfg = &(p_xran_dev_ctx->srs_cfg);

    num_ant_elm = xran_get_num_ant_elm(pHandle);
    enum xran_pkt_dir direction;

    struct rte_mbuf *eth_oran_hdr = NULL;
    char        *ext_buff = NULL;
    uint16_t    ext_buff_len = 0;
    struct rte_mbuf *tmp = NULL;
    rte_iova_t ext_buff_iova = 0;

    if(p_xran_dev_ctx->xran_port_id >= XRAN_PORTS_NUM)
        rte_panic("incorrect PORT ID\n");

    struct rte_mbuf_ext_shared_info * p_share_data = NULL;
    if(p_xran_dev_ctx->fh_init.io_cfg.id == O_DU) {
        direction = XRAN_DIR_DL; /* O-DU */
        prb_num = p_xran_dev_ctx->fh_cfg.nDLRBs;
    } else {
        direction = XRAN_DIR_UL; /* RU */
        prb_num = p_xran_dev_ctx->fh_cfg.nULRBs;
    }

    if(xran_fs_get_slot_type(cc_id, tti, ((p_xran_dev_ctx->fh_init.io_cfg.id == O_DU)? XRAN_SLOT_TYPE_DL : XRAN_SLOT_TYPE_UL)) ==  1
            || xran_fs_get_slot_type(cc_id, tti, XRAN_SLOT_TYPE_SP) ==  1
            || xran_fs_get_slot_type(cc_id, tti, XRAN_SLOT_TYPE_FDD) ==  1){

        if(xran_fs_get_symbol_type(cc_id, tti, sym_id) == ((p_xran_dev_ctx->fh_init.io_cfg.id == O_DU)? XRAN_SYMBOL_TYPE_DL : XRAN_SYMBOL_TYPE_UL)
           || xran_fs_get_symbol_type(cc_id, tti, sym_id) == XRAN_SYMBOL_TYPE_FDD){

            vf_id = xran_map_ecpriPcid_to_vf(p_xran_dev_ctx, direction, cc_id, ant_id);
            pos = (char*) p_xran_dev_ctx->sFrontHaulTxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pData;
            mb  = (void*) p_xran_dev_ctx->sFrontHaulTxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pCtrl;
            prb_map  = (struct xran_prb_map *) p_xran_dev_ctx->sFrontHaulTxPrbMapBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers->pData;


            if(prb_map){
                int32_t elmIdx = 0;
                for (elmIdx = 0; elmIdx < prb_map->nPrbElm && elmIdx < XRAN_MAX_SECTIONS_PER_SLOT; elmIdx++){
                    uint16_t sec_id  = elmIdx;
                    struct xran_prb_elm * prb_map_elm = &prb_map->prbMap[elmIdx];
                    struct xran_section_desc * p_sec_desc = NULL;
                    p_share_data = &p_xran_dev_ctx->share_data.sh_data[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id][sec_id];

                    if(prb_map_elm == NULL){
                        rte_panic("p_sec_desc == NULL\n");
                    }

                    p_sec_desc =  prb_map_elm->p_sec_desc[sym_id][0];

                    p_sec_iq     = ((char*)pos + p_sec_desc->iq_buffer_offset);

                    /* calculate offset for external buffer */
                    ext_buff_len = p_sec_desc->iq_buffer_len;
                    ext_buff = p_sec_iq - (RTE_PKTMBUF_HEADROOM +
                                    sizeof (struct xran_ecpri_hdr) +
                                    sizeof (struct radio_app_common_hdr) +
                                    sizeof(struct data_section_hdr));

                    ext_buff_len += RTE_PKTMBUF_HEADROOM +
                                    sizeof (struct xran_ecpri_hdr) +
                                    sizeof (struct radio_app_common_hdr) +
                                    sizeof(struct data_section_hdr) + 18;

                    if(prb_map_elm->compMethod != XRAN_COMPMETHOD_NONE){
                        ext_buff     -= sizeof (struct data_section_compression_hdr);
                        ext_buff_len += sizeof (struct data_section_compression_hdr);
                    }

                    eth_oran_hdr = rte_pktmbuf_alloc(_eth_mbuf_pool_vf_small[vf_id]);
                    if (unlikely (( eth_oran_hdr) == NULL)) {
                        rte_panic("Failed rte_pktmbuf_alloc\n");
                    }

                    p_share_data->free_cb = extbuf_free_callback;
                    p_share_data->fcb_opaque = NULL;
                    rte_mbuf_ext_refcnt_set(p_share_data, 1);

                    ext_buff_iova = rte_mempool_virt2iova(mb);
                    if (unlikely (( ext_buff_iova) == 0)) {
                        rte_panic("Failed rte_mem_virt2iova \n");
                    }

                    if (unlikely (( (rte_iova_t)ext_buff_iova) == RTE_BAD_IOVA)) {
                        rte_panic("Failed rte_mem_virt2iova RTE_BAD_IOVA \n");
                    }

                    rte_pktmbuf_attach_extbuf(eth_oran_hdr,
                                              ext_buff,
                                              ext_buff_iova + RTE_PTR_DIFF(ext_buff , mb),
                                              ext_buff_len,
                                              p_share_data);

                    rte_pktmbuf_reset_headroom(eth_oran_hdr);

                    tmp = (struct rte_mbuf *)rte_pktmbuf_prepend(eth_oran_hdr, sizeof(struct rte_ether_hdr));
                    if (unlikely (( tmp) == NULL)) {
                        rte_panic("Failed rte_pktmbuf_prepend \n");
                    }
                    send_mb = eth_oran_hdr;


                    uint8_t seq_id = (p_xran_dev_ctx->fh_init.io_cfg.id == O_DU) ?
                                          xran_get_updl_seqid(pHandle, cc_id, ant_id) :
                                          xran_get_upul_seqid(pHandle, cc_id, ant_id);



                    /* first all PRBs */
                    int32_t num_bytes = prepare_symbol_ex(direction, sec_id,
                                      send_mb,
                                      (uint8_t *)p_sec_iq,
                                      prb_map_elm->compMethod,
                                      prb_map_elm->iqWidth,
                                      p_xran_dev_ctx->fh_cfg.ru_conf.byteOrder,
                                      frame_id, subframe_id, slot_id, sym_id,
                                      prb_map_elm->nRBStart, prb_map_elm->nRBSize,
                                      cc_id, ant_id,
                                      seq_id,
                                      0);

                    rte_mbuf_sanity_check((struct rte_mbuf *)send_mb, 0);
                    pCnt->tx_counter++;
                    pCnt->tx_bytes_counter += rte_pktmbuf_pkt_len((struct rte_mbuf *)send_mb);
                    p_xran_dev_ctx->send_upmbuf2ring((struct rte_mbuf *)send_mb, ETHER_TYPE_ECPRI, vf_id);
                }
            } else {
                printf("(%d %d %d %d) prb_map == NULL\n", tti % XRAN_N_FE_BUF_LEN, cc_id, ant_id, sym_id);
            }

            if(p_xran_dev_ctx->enablePrach
                && (p_xran_dev_ctx->fh_init.io_cfg.id == O_RU)) {   /* Only RU needs to send PRACH I/Q */
                uint32_t is_prach_slot = xran_is_prach_slot(subframe_id, slot_id);

                if(((frame_id % pPrachCPConfig->x) == pPrachCPConfig->y[0])
                        && (is_prach_slot == 1)
                        && (sym_id >= p_xran_dev_ctx->prach_start_symbol[cc_id])
                        && (sym_id <= p_xran_dev_ctx->prach_last_symbol[cc_id])) {
                    int prach_port_id = ant_id + pPrachCPConfig->eAxC_offset;
                    int compMethod, parm_size;
                    uint8_t symb_id_offset = sym_id - p_xran_dev_ctx->prach_start_symbol[cc_id];

                    compMethod = p_xran_dev_ctx->fh_cfg.ru_conf.compMeth;
                    switch(compMethod) {
                        case XRAN_COMPMETHOD_BLKFLOAT:      parm_size = 1; break;
                        case XRAN_COMPMETHOD_MODULATION:    parm_size = 0; break;
                        default:
                            parm_size = 0;
                        }
                    pos = (char*) p_xran_dev_ctx->sFHPrachRxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[symb_id_offset].pData;
                    //pos += (sym_id - p_xran_dev_ctx->prach_start_symbol[cc_id]) * pPrachCPConfig->numPrbc * N_SC_PER_PRB * 4;
                    /*pos += (sym_id - p_xran_dev_ctx->prach_start_symbol[cc_id])
                            * (3*p_xran_dev_ctx->fh_cfg.ru_conf.iqWidth + parm_size)
                            * pPrachCPConfig->numPrbc;*/
                    mb  = NULL;//(void*) p_xran_dev_ctx->sFHPrachRxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[0].pCtrl;

                    send_symbol_ex(pHandle,
                            direction,
                            xran_alloc_sectionid(pHandle, direction, cc_id, prach_port_id, slot_id),
                            (struct rte_mbuf *)mb,
                            (uint8_t *)pos,
                            compMethod,
                            p_xran_dev_ctx->fh_cfg.ru_conf.iqWidth,
                            p_xran_dev_ctx->fh_cfg.ru_conf.byteOrder,
                            frame_id, subframe_id, slot_id, sym_id,
                            pPrachCPConfig->startPrbc, pPrachCPConfig->numPrbc,
                            cc_id, prach_port_id,
                            xran_get_upul_seqid(pHandle, cc_id, prach_port_id));
                    retval = 1;
                }
            } /* if(p_xran_dev_ctx->enablePrach ..... */
        } /* RU mode or C-Plane is not used */
    }

    return retval;
}

int32_t
xran_process_tx_srs_cp_off(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id, uint32_t slot_id, uint32_t sym_id)
{
    int32_t     retval = 0;
    char        *pos = NULL;
    char        *p_sec_iq = NULL;
    void        *mb  = NULL;
    void        *send_mb  = NULL;
    int         prb_num = 0;
    uint16_t    iq_sample_size_bits = 16;

    struct xran_prb_map *prb_map = NULL;
    uint8_t  num_ant_elm  = 0;

    struct xran_device_ctx * p_xran_dev_ctx = (struct xran_device_ctx *)pHandle;
    struct xran_common_counters * pCnt = &p_xran_dev_ctx->fh_counters;
    struct xran_prach_cp_config *pPrachCPConfig = &(p_xran_dev_ctx->PrachCPConfig);
    struct xran_srs_config *p_srs_cfg = &(p_xran_dev_ctx->srs_cfg);

    num_ant_elm = xran_get_num_ant_elm(pHandle);
    enum xran_pkt_dir direction;

    struct rte_mbuf *eth_oran_hdr = NULL;
    char        *ext_buff = NULL;
    uint16_t    ext_buff_len = 0;
    struct rte_mbuf *tmp = NULL;
    rte_iova_t ext_buff_iova = 0;
    int32_t ant_elm_eAxC_id = ant_id + p_srs_cfg->eAxC_offset;
    uint32_t vf_id = 0;

    if(p_xran_dev_ctx->xran_port_id >= XRAN_PORTS_NUM)
        rte_panic("incorrect PORT ID\n");

    struct rte_mbuf_ext_shared_info * p_share_data = NULL;

    if(p_xran_dev_ctx->fh_init.io_cfg.id == O_DU) {
        direction = XRAN_DIR_DL; /* O-DU */
        prb_num = p_xran_dev_ctx->fh_cfg.nDLRBs;
        rte_panic("incorrect O_DU\n");
    } else {
        direction = XRAN_DIR_UL; /* RU */
        prb_num = p_xran_dev_ctx->fh_cfg.nULRBs;
    }

#if 1
    if (tti % 5 == 3) {
        {
#else
    if(xran_fs_get_slot_type(cc_id, tti, XRAN_SLOT_TYPE_UL) ==  1
            || xran_fs_get_slot_type(cc_id, tti, XRAN_SLOT_TYPE_FDD) ==  1) {
        if(xran_fs_get_symbol_type(cc_id, tti, sym_id) == XRAN_SYMBOL_TYPE_UL
           || xran_fs_get_symbol_type(cc_id, tti, sym_id) == XRAN_SYMBOL_TYPE_FDD) {
#endif
            pos = (char*) p_xran_dev_ctx->sFHSrsRxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pData;
            mb  = (void*) p_xran_dev_ctx->sFHSrsRxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pCtrl;
            prb_map  = (struct xran_prb_map *) p_xran_dev_ctx->sFHSrsRxPrbMapBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers->pData;
            vf_id  = xran_map_ecpriPcid_to_vf(p_xran_dev_ctx, direction, cc_id, ant_elm_eAxC_id);

            if(prb_map) {
                int32_t elmIdx = 0;
                for (elmIdx = 0; elmIdx < prb_map->nPrbElm && elmIdx < XRAN_MAX_SECTIONS_PER_SLOT; elmIdx++) {
                    uint16_t sec_id  = elmIdx;
                    struct xran_prb_elm * prb_map_elm = &prb_map->prbMap[elmIdx];
                    struct xran_section_desc * p_sec_desc = NULL;

                    if(prb_map_elm == NULL) {
                        rte_panic("p_sec_desc == NULL\n");
                    }

                    /* skip, if not scheduled */
                    if(sym_id < prb_map_elm->nStartSymb || sym_id >= prb_map_elm->nStartSymb + prb_map_elm->numSymb)
                        return 0;

                    p_share_data = &p_xran_dev_ctx->srs_share_data.sh_data[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id];
                    p_sec_desc =  prb_map_elm->p_sec_desc[sym_id][0];
                    p_sec_iq     = ((char*)pos + p_sec_desc->iq_buffer_offset);

                    /* calculete offset for external buffer */
                    ext_buff_len = p_sec_desc->iq_buffer_len;
                    ext_buff = p_sec_iq - (RTE_PKTMBUF_HEADROOM +
                                    sizeof (struct xran_ecpri_hdr) +
                                    sizeof (struct radio_app_common_hdr) +
                                    sizeof(struct data_section_hdr));

                    ext_buff_len += RTE_PKTMBUF_HEADROOM +
                                    sizeof (struct xran_ecpri_hdr) +
                                    sizeof (struct radio_app_common_hdr) +
                                    sizeof(struct data_section_hdr) + 18;

                    if(prb_map_elm->compMethod != XRAN_COMPMETHOD_NONE){
                        ext_buff     -= sizeof (struct data_section_compression_hdr);
                        ext_buff_len += sizeof (struct data_section_compression_hdr);
                    }

//                    eth_oran_hdr =  rte_pktmbuf_alloc(_eth_mbuf_pool_small);
                    eth_oran_hdr = xran_ethdi_mbuf_indir_alloc();

                    if (unlikely (( eth_oran_hdr) == NULL)) {
                        rte_panic("Failed rte_pktmbuf_alloc\n");
                    }

                    p_share_data->free_cb = extbuf_free_callback;
                    p_share_data->fcb_opaque = NULL;
                    rte_mbuf_ext_refcnt_set(p_share_data, 1);

                    ext_buff_iova = rte_mempool_virt2iova(mb);
                    if (unlikely (( ext_buff_iova) == 0)) {
                        rte_panic("Failed rte_mem_virt2iova \n");
                    }

                    if (unlikely (( (rte_iova_t)ext_buff_iova) == RTE_BAD_IOVA)) {
                        rte_panic("Failed rte_mem_virt2iova RTE_BAD_IOVA \n");
                    }

                    rte_pktmbuf_attach_extbuf(eth_oran_hdr,
                                              ext_buff,
                                              ext_buff_iova + RTE_PTR_DIFF(ext_buff , mb),
                                              ext_buff_len,
                                              p_share_data);

                    rte_pktmbuf_reset_headroom(eth_oran_hdr);

                    tmp = (struct rte_mbuf *)rte_pktmbuf_prepend(eth_oran_hdr, sizeof(struct rte_ether_hdr));
                    if (unlikely (( tmp) == NULL)) {
                        rte_panic("Failed rte_pktmbuf_prepend \n");
                    }
                    send_mb = eth_oran_hdr;

                    uint8_t seq_id = (p_xran_dev_ctx->fh_init.io_cfg.id == O_DU) ?
                                          xran_get_updl_seqid(pHandle, cc_id, ant_elm_eAxC_id) :
                                          xran_get_upul_seqid(pHandle, cc_id, ant_elm_eAxC_id);
                    /* first all PRBs */
                    int32_t num_bytes = prepare_symbol_ex(direction, sec_id,
                                      send_mb,
                                      (uint8_t *)p_sec_iq,
                                      prb_map_elm->compMethod,
                                      prb_map_elm->iqWidth,
                                      p_xran_dev_ctx->fh_cfg.ru_conf.byteOrder,
                                      frame_id, subframe_id, slot_id, sym_id,
                                      prb_map_elm->nRBStart, prb_map_elm->nRBSize,
                                      cc_id, ant_elm_eAxC_id,
                                      seq_id,
                                      0);

                    rte_mbuf_sanity_check((struct rte_mbuf *)send_mb, 0);
                    pCnt->tx_counter++;
                    pCnt->tx_bytes_counter += rte_pktmbuf_pkt_len((struct rte_mbuf *)send_mb);
                    p_xran_dev_ctx->send_upmbuf2ring((struct rte_mbuf *)send_mb, ETHER_TYPE_ECPRI, vf_id);
                }
            } else {
                printf("(%d %d %d %d) prb_map == NULL\n", tti % XRAN_N_FE_BUF_LEN, cc_id, ant_elm_eAxC_id, sym_id);
            }
        }
    }

    return retval;
}

struct rte_mbuf *
xran_attach_up_ext_buf(uint16_t vf_id, int8_t* p_ext_buff_start, int8_t* p_ext_buff, uint16_t ext_buff_len,
                struct rte_mbuf_ext_shared_info * p_share_data,
                enum xran_compression_method compMeth)
{
    struct rte_mbuf *mb_oran_hdr_ext = NULL;
    struct rte_mbuf *tmp             = NULL;
    int8_t          *ext_buff        = NULL;
    rte_iova_t ext_buff_iova         = 0;
    ext_buff =      p_ext_buff - (RTE_PKTMBUF_HEADROOM +
                    sizeof(struct xran_ecpri_hdr) +
                    sizeof(struct radio_app_common_hdr) +
                    sizeof(struct data_section_hdr));

    ext_buff_len += RTE_PKTMBUF_HEADROOM +
                    sizeof(struct xran_ecpri_hdr) +
                    sizeof(struct radio_app_common_hdr) +
                    sizeof(struct data_section_hdr) + 18;
#ifdef FCN_ADAPT
    ext_buff     -= sizeof (struct data_section_compression_hdr);
    ext_buff_len += sizeof (struct data_section_compression_hdr);
#else
    if(compMeth != XRAN_COMPMETHOD_NONE) {
        ext_buff     -= sizeof (struct data_section_compression_hdr);
        ext_buff_len += sizeof (struct data_section_compression_hdr);
    }
#endif
    mb_oran_hdr_ext =  rte_pktmbuf_alloc(_eth_mbuf_pool_vf_small[vf_id]);

    if (unlikely (( mb_oran_hdr_ext) == NULL)) {
        rte_panic("[core %d]Failed rte_pktmbuf_alloc on vf %d\n", rte_lcore_id(), vf_id);
    }

    p_share_data->free_cb = extbuf_free_callback;
    p_share_data->fcb_opaque = NULL;
    rte_mbuf_ext_refcnt_set(p_share_data, 1);

    ext_buff_iova = rte_mempool_virt2iova(p_ext_buff_start);
    if (unlikely (( ext_buff_iova) == 0)) {
        rte_panic("Failed rte_mem_virt2iova \n");
    }

    if (unlikely (( (rte_iova_t)ext_buff_iova) == RTE_BAD_IOVA)) {
        rte_panic("Failed rte_mem_virt2iova RTE_BAD_IOVA \n");
    }

    rte_pktmbuf_attach_extbuf(mb_oran_hdr_ext,
                              ext_buff,
                              ext_buff_iova + RTE_PTR_DIFF(ext_buff , p_ext_buff_start),
                              ext_buff_len,
                              p_share_data);

    rte_pktmbuf_reset_headroom(mb_oran_hdr_ext);

    tmp = (struct rte_mbuf *)rte_pktmbuf_prepend(mb_oran_hdr_ext, sizeof(struct rte_ether_hdr));
    if (unlikely (( tmp) == NULL)) {
        rte_panic("Failed rte_pktmbuf_prepend \n");
    }

    return mb_oran_hdr_ext;
}

int32_t
xran_process_tx_sym_cp_on_dispatch(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id,
                                   uint32_t slot_id, uint32_t sym_id)
{
    int32_t     retval = 0;
    struct cp_up_tx_desc*   p_desc = NULL;
    struct xran_ethdi_ctx*  eth_ctx = xran_ethdi_get_ctx();
    struct xran_device_ctx* p_xran_dev_ctx = (struct xran_device_ctx*)pHandle;

    p_desc = xran_pkt_gen_desc_alloc();
    if(p_desc) {
        p_desc->pHandle     = pHandle;
        p_desc->ctx_id      = ctx_id;
        p_desc->tti         = tti;
        p_desc->cc_id       = cc_id;
        p_desc->ant_id      = ant_id;
        p_desc->frame_id    = frame_id;
        p_desc->subframe_id = subframe_id;
        p_desc->slot_id     = slot_id;
        p_desc->sym_id      = sym_id;

        if(likely(p_xran_dev_ctx->xran_port_id < XRAN_PORTS_NUM)) {
            if (rte_ring_enqueue(eth_ctx->up_dl_pkt_gen_ring[p_xran_dev_ctx->xran_port_id], p_desc->mb) == 0)
                return 1;   /* success */
            else
                xran_pkt_gen_desc_free(p_desc);
        } else {
            rte_panic("incorrect port %d", p_xran_dev_ctx->xran_port_id);
        }
    } else {
        print_dbg("xran_pkt_gen_desc_alloc failure %d", p_xran_dev_ctx->xran_port_id);
    }

    return retval;
}

int32_t
xran_process_tx_sym_cp_on(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id,
    uint32_t slot_id, uint32_t sym_id)
{
    int32_t     retval = 0;

    struct rte_mbuf *eth_oran_hdr = NULL;
    char        *ext_buff = NULL;
    uint16_t    ext_buff_len = 0;
    struct rte_mbuf *tmp = NULL;
    rte_iova_t ext_buff_iova = 0;
    char        *pos      = NULL;
    char        *p_sec_iq = NULL;
    void        *mb  = NULL;
    struct rte_mbuf *to_free_mbuf =  NULL;
    int         prb_num = 0;
    uint16_t    iq_sample_size_bits = 16;
    uint32_t    next = 0;
    int32_t     num_sections = 0;
    uint16_t    len  = 0;
    int16_t     len2 = 0;
    uint16_t    i    = 0;

    uint64_t    t1;
    struct mbuf_table  loc_tx_mbufs;
    struct xran_up_pkt_gen_params loc_xp;

    struct xran_section_info *sectinfo = NULL;
    struct xran_device_ctx   *p_xran_dev_ctx = (struct xran_device_ctx*)pHandle;
    enum xran_pkt_dir direction;
    uint16_t vf_id = 0;

    struct rte_mbuf_ext_shared_info * p_share_data = NULL;

    if(p_xran_dev_ctx->fh_init.io_cfg.id == O_DU) {
        direction = XRAN_DIR_DL; /* O-DU */
        prb_num = p_xran_dev_ctx->fh_cfg.nDLRBs;
    } else {
        direction = XRAN_DIR_UL; /* RU */
        prb_num = p_xran_dev_ctx->fh_cfg.nULRBs;
    }

    vf_id = xran_map_ecpriPcid_to_vf(p_xran_dev_ctx, direction, cc_id, ant_id);
    next = 0;
    num_sections = xran_cp_getsize_section_info(pHandle, direction, cc_id, ant_id, ctx_id);
    /* iterate C-Plane configuration to generate corresponding U-Plane */
    if(num_sections)
        prepare_sf_slot_sym(direction, frame_id, subframe_id, slot_id, sym_id, &loc_xp);

    loc_tx_mbufs.len = 0;
    while(next < num_sections) {
        sectinfo = xran_cp_iterate_section_info(pHandle, direction, cc_id, ant_id, ctx_id, &next);

        if(sectinfo == NULL)
            break;

        if(sectinfo->type != XRAN_CP_SECTIONTYPE_1) {   /* only supports type 1 */
            print_err("Invalid section type in section DB - %d", sectinfo->type);
            continue;
        }

        /* skip, if not scheduled */
        if(sym_id < sectinfo->startSymId || sym_id >= sectinfo->startSymId + sectinfo->numSymbol)
            continue;


        if(sectinfo->compMeth)
            iq_sample_size_bits = sectinfo->iqWidth;

        print_dbg(">>> sym %2d [%d] type%d id %d startPrbc=%d numPrbc=%d startSymId=%d numSymbol=%d\n", sym_id, next,
                    sectinfo->type, sectinfo->id, sectinfo->startPrbc,
                    sectinfo->numPrbc,sectinfo->startSymId, sectinfo->numSymbol);

        p_share_data = &p_xran_dev_ctx->share_data.sh_data[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id][sectinfo->id];

        len  = loc_tx_mbufs.len;
        len2 = 0;
        i    = 0;

        //Added for Klocworks
        if (len >= MBUF_TABLE_SIZE) {
            len = MBUF_TABLE_SIZE - 1;
            rte_panic("len >= MBUF_TABLE_SIZE\n");
        }

        to_free_mbuf  = p_xran_dev_ctx->to_free_mbuf[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id][sym_id][sectinfo->id];
        pos = (char*) p_xran_dev_ctx->sFrontHaulTxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pData;
        mb  = p_xran_dev_ctx->sFrontHaulTxBbuIoBufCtrl[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id].sBufferList.pBuffers[sym_id].pCtrl;

        if(mb == NULL) {
            rte_panic("mb == NULL\n");
        }

        p_sec_iq     = ((char*)pos + sectinfo->sec_desc[sym_id].iq_buffer_offset);
        ext_buff_len = sectinfo->sec_desc[sym_id].iq_buffer_len;

        mb = xran_attach_up_ext_buf(vf_id, (int8_t *)mb, (int8_t *) p_sec_iq,
                            (uint16_t) ext_buff_len,
                            p_share_data, (enum xran_compression_method) sectinfo->compMeth);
        p_xran_dev_ctx->to_free_mbuf[tti % XRAN_N_FE_BUF_LEN][cc_id][ant_id][sym_id][sectinfo->id] =  mb;
        rte_pktmbuf_refcnt_update(mb, 1); /* make sure eth won't free our mbuf */

        if(to_free_mbuf) {
            rte_pktmbuf_free(to_free_mbuf);
        }

        /* first all PRBs */
        prepare_symbol_opt(direction, sectinfo->id,
                          mb,
                          (struct rb_map *)p_sec_iq,
                          sectinfo->compMeth,
                          sectinfo->iqWidth,
                          p_xran_dev_ctx->fh_cfg.ru_conf.byteOrder,
                          sectinfo->startPrbc, sectinfo->numPrbc,
                          cc_id, ant_id,
                          xran_get_updl_seqid(pHandle, cc_id, ant_id),
                          0,
                          &loc_xp);

        /* if we don't need to do any fragmentation */
        if (likely (p_xran_dev_ctx->fh_init.mtu >=
                        sectinfo->numPrbc * (3*iq_sample_size_bits + 1))) {
            /* no fragmentation */
            loc_tx_mbufs.m_table[len] = mb;
            len2 = 1;
        } else {
            /* fragmentation */
            uint8_t * seq_num = xran_get_updl_seqid_addr(pHandle, cc_id, ant_id);
            if(seq_num)
                (*seq_num)--;
            else
                rte_panic("pointer to seq number is NULL [CC %d Ant %d]\n", cc_id, ant_id);
#ifdef FCN_ADAPT
            len2 = xran_app_fragment_packet(mb,
                            &loc_tx_mbufs.m_table[len],
                            (uint16_t)(MBUF_TABLE_SIZE - len),
                            p_xran_dev_ctx->fh_init.mtu,
                            p_xran_dev_ctx->direct_pool,
                            p_xran_dev_ctx->indirect_pool,
                            sectinfo->startPrbc,
                            sectinfo->numPrbc,
                            seq_num,
                            sectinfo->iqWidth,
                            1);
#else
            len2 = xran_app_fragment_packet(mb,
                            &loc_tx_mbufs.m_table[len],
                            (uint16_t)(MBUF_TABLE_SIZE - len),
                            p_xran_dev_ctx->fh_init.mtu,
                            p_xran_dev_ctx->direct_pool,
                            p_xran_dev_ctx->indirect_pool,
                            sectinfo->startPrbc,
                            sectinfo->numPrbc,
                            seq_num,
                            sectinfo->iqWidth,
                            (sectinfo->iqWidth == 16) ? 0 : 1);
#endif

            /* Free input packet */
            rte_pktmbuf_free(mb);

            /* If we fail to fragment the packet */
            if (unlikely (len2 < 0)){
                print_err("len2= %d\n", len2);
                return 0;
            }
        }
        if(len2 > 1){
            for (i = len; i < len + len2; i ++) {
                struct rte_mbuf *m;
                m = loc_tx_mbufs.m_table[i];
                struct rte_ether_hdr *eth_hdr = (struct rte_ether_hdr *)
                    rte_pktmbuf_prepend(m, (uint16_t)sizeof(struct rte_ether_hdr));
                if (eth_hdr == NULL) {
                    rte_panic("No headroom in mbuf.\n");
                }
            }
        }

        len += len2;
        if (unlikely(len > XRAN_MAX_PKT_BURST_PER_SYM)) {
              rte_panic("XRAN_MAX_PKT_BURST_PER_SYM\n");
        }
        loc_tx_mbufs.len = len;
    } /* while(section) */

    /* Transmit packets */
    xran_send_burst(p_xran_dev_ctx, &loc_tx_mbufs, vf_id);
    loc_tx_mbufs.len = 0;
    retval = 1;

    return retval;
}

int32_t xran_process_tx_sym(void *arg)
{
    int32_t     retval = 0;
    uint32_t    tti=0;
#if XRAN_MLOG_VAR
    uint32_t    mlogVar[15];
    uint32_t    mlogVarCnt = 0;
#endif
    unsigned long t1 = MLogTick();

    void        *pHandle = NULL;
    int32_t     ant_id   = 0;
    int32_t     cc_id    = 0;
    uint8_t     num_eAxc = 0;
    uint8_t     num_eAxAntElm = 0;
    uint8_t     num_CCPorts = 0;
    uint32_t    frame_id    = 0;
    uint32_t    subframe_id = 0;
    uint32_t    slot_id     = 0;
    uint32_t    sym_id      = 0;
    uint32_t    sym_idx     = 0;

    uint8_t     ctx_id;
    struct xran_device_ctx * p_xran_dev_ctx = (struct xran_device_ctx *) arg;
    enum xran_in_period inPeriod;

    if(p_xran_dev_ctx->xran2phy_mem_ready == 0)
        return 0;

    pHandle =  p_xran_dev_ctx;

    /* O-RU: send symb after OTA time with delay (UL) */
    /* O-DU: send symb in advance of OTA time (DL) */
    sym_idx     = XranOffsetSym(p_xran_dev_ctx->sym_up, xran_lib_ota_sym_idx, XRAN_NUM_OF_SYMBOL_PER_SLOT*SLOTNUM_PER_SUBFRAME*1000, &inPeriod);

    tti         = XranGetTtiNum(sym_idx, XRAN_NUM_OF_SYMBOL_PER_SLOT);
    slot_id     = XranGetSlotNum(tti, SLOTNUM_PER_SUBFRAME);
    subframe_id = XranGetSubFrameNum(tti,SLOTNUM_PER_SUBFRAME,  SUBFRAMES_PER_SYSTEMFRAME);

    uint16_t sfnSecStart = xran_getSfnSecStart();
    if (unlikely(inPeriod == XRAN_IN_NEXT_PERIOD))
    {
        // For DU
        sfnSecStart = (sfnSecStart + NUM_OF_FRAMES_PER_SECOND) & 0x3ff;
    }
    else if (unlikely(inPeriod == XRAN_IN_PREV_PERIOD))
    {
        // For RU
        if (sfnSecStart >= NUM_OF_FRAMES_PER_SECOND)
        {
            sfnSecStart -= NUM_OF_FRAMES_PER_SECOND;
        }
        else
        {
            sfnSecStart += NUM_OF_FRAMES_PER_SFN_PERIOD - NUM_OF_FRAMES_PER_SECOND;
        }
    }
    frame_id    = XranGetFrameNum(tti,sfnSecStart,SUBFRAMES_PER_SYSTEMFRAME, SLOTNUM_PER_SUBFRAME);
    // ORAN frameId, 8 bits, [0, 255]
    frame_id = (frame_id & 0xff);

    sym_id      = XranGetSymNum(sym_idx, XRAN_NUM_OF_SYMBOL_PER_SLOT);
    ctx_id      = XranGetSlotNum(tti, SLOTS_PER_SYSTEMFRAME) % XRAN_MAX_SECTIONDB_CTX;

    print_dbg("[%d]SFN %d sf %d slot %d\n", tti, frame_id, subframe_id, slot_id);

#if XRAN_MLOG_VAR
    mlogVar[mlogVarCnt++] = 0xAAAAAAAA;
    mlogVar[mlogVarCnt++] = xran_lib_ota_sym_idx;
    mlogVar[mlogVarCnt++] = sym_idx;
    mlogVar[mlogVarCnt++] = abs(p_xran_dev_ctx->sym_up);
    mlogVar[mlogVarCnt++] = tti;
    mlogVar[mlogVarCnt++] = frame_id;
    mlogVar[mlogVarCnt++] = subframe_id;
    mlogVar[mlogVarCnt++] = slot_id;
    mlogVar[mlogVarCnt++] = sym_id;
    mlogVar[mlogVarCnt++] = p_xran_dev_ctx->xran_port_id;
    MLogAddVariables(mlogVarCnt, mlogVar, MLogTick());
#endif

    if(p_xran_dev_ctx->fh_init.io_cfg.id == O_RU && xran_get_ru_category(pHandle) == XRAN_CATEGORY_B) {
            num_eAxc    = xran_get_num_eAxcUl(pHandle);
    } else {
            num_eAxc    = xran_get_num_eAxc(pHandle);
    }

    num_CCPorts = xran_get_num_cc(pHandle);
    /* U-Plane */
    for(ant_id = 0; ant_id < num_eAxc; ant_id++) {
        for(cc_id = 0; cc_id < num_CCPorts; cc_id++) {
            if(p_xran_dev_ctx->fh_init.io_cfg.id == O_DU && p_xran_dev_ctx->enableCP) {
                if(p_xran_dev_ctx->tx_sym_gen_func) {
                    retval  = p_xran_dev_ctx->tx_sym_gen_func(pHandle, ctx_id, tti, cc_id, ant_id, frame_id, subframe_id, slot_id, sym_id);
                } else {
                    rte_panic("p_xran_dev_ctx->tx_sym_gen_func== NULL\n");
                }

            } else {
                struct xran_srs_config *p_srs_cfg = &(p_xran_dev_ctx->srs_cfg);
                retval = xran_process_tx_sym_cp_off(pHandle, ctx_id, tti, cc_id, ant_id, frame_id, subframe_id, slot_id, sym_id, 0);

                if(p_xran_dev_ctx->enableSrs && (p_srs_cfg->symbMask & (1 << sym_id))) {
                    retval = xran_process_tx_srs_cp_off(pHandle, ctx_id, tti, cc_id, ant_id, frame_id, subframe_id, slot_id, sym_id);
                }
            }
        } /* for(cc_id = 0; cc_id < num_CCPorts; cc_id++) */
    } /* for(ant_id = 0; ant_id < num_eAxc; ant_id++) */

    if(p_xran_dev_ctx->fh_init.io_cfg.id == O_RU && p_xran_dev_ctx->enableSrs && xran_get_ru_category(pHandle) == XRAN_CATEGORY_B) {
        num_eAxAntElm = xran_get_num_ant_elm(pHandle);
        struct xran_srs_config *p_srs_cfg = &(p_xran_dev_ctx->srs_cfg);
        for(num_eAxc = 0; ant_id < num_eAxAntElm; ant_id++) {
            for(cc_id = 0; cc_id < num_CCPorts; cc_id++) {
                if( p_srs_cfg->symbMask & (1 << sym_id)) {
                    retval = xran_process_tx_srs_cp_off(pHandle, ctx_id, tti, cc_id, ant_id, frame_id, subframe_id, slot_id, sym_id);
                }
            }
        }
    }

    MLogTask(PID_DISPATCH_TX_SYM, t1, MLogTick());
    return retval;
}

struct cp_up_tx_desc *
xran_pkt_gen_desc_alloc(void)
{
    struct rte_mbuf * mb =  rte_pktmbuf_alloc(_eth_mbuf_pkt_gen);
    struct cp_up_tx_desc * p_desc = NULL;
    char * start     = NULL;

    if(mb){
        start     = rte_pktmbuf_append(mb, sizeof(struct cp_up_tx_desc));
        if(start) {
            p_desc = rte_pktmbuf_mtod(mb,  struct cp_up_tx_desc *);
            if(p_desc){
                p_desc->mb = mb;
                return p_desc;
            }
        }
    }
    return p_desc;
}

int32_t
xran_pkt_gen_desc_free(struct cp_up_tx_desc *p_desc)
{
    if (p_desc){
        if(p_desc->mb){
            rte_pktmbuf_free(p_desc->mb);
            return 0;
        } else {
            rte_panic("p_desc->mb == NULL\n");
        }
    }
    return -1;
}

