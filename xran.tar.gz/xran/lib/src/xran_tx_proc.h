/******************************************************************************
*
*   Copyright (c) 2020 Intel.
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
*
*******************************************************************************/

/**
 * @brief XRAN TX header file
 * @file xran_tx_proc.h
 * @ingroup group_source_xran
 * @author Intel Corporation
 **/

#ifndef _XRAN_TX_PROC_H_
#define _XRAN_TX_PROC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/queue.h>

#include <rte_common.h>
#include <rte_mbuf.h>
#include <rte_timer.h>

#include "xran_fh_o_du.h"
#include "xran_prach_cfg.h"
#include "xran_up_api.h"

struct cp_up_tx_desc {
    struct rte_mbuf * mb;
    void *pHandle;
    uint8_t ctx_id;
    uint32_t tti;
    int32_t cc_id;
    int32_t ant_id;
    uint32_t frame_id;
    uint32_t subframe_id;
    uint32_t slot_id;
    uint32_t sym_id;
};

int32_t xran_process_tx_sym(void *arg);

struct cp_up_tx_desc * xran_pkt_gen_desc_alloc(void);
int32_t xran_pkt_gen_desc_free(struct cp_up_tx_desc *p_desc);
uint16_t xran_getSfnSecStart(void);

int32_t xran_process_tx_sym_cp_on_dispatch(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id,
    uint32_t slot_id, uint32_t sym_id);
int32_t xran_process_tx_sym_cp_on(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id,
    uint32_t slot_id, uint32_t sym_id);
int32_t xran_process_tx_sym_cp_on_dispatch(void *pHandle, uint8_t ctx_id, uint32_t tti, int32_t cc_id, int32_t ant_id, uint32_t frame_id, uint32_t subframe_id,
    uint32_t slot_id, uint32_t sym_id);

#ifdef __cplusplus
}
#endif

#endif /* _XRAN_TX_PROC_H_ */
